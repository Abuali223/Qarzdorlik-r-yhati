# Nasiya & To'lovlar (PWA)

- Mahalliy `localStorage`da saqlanadi (backend talab qilmaydi)
- Mijoz qo'shish / tahrirlash / o'chirish
- Qarz va To'lov yozuvlari alohida tugma orqali
- Jami qarz, Qaytgan to'lov, Qoldiq statistikasi
- Qidirish, JSON import/eksport
- Mobil & desktop uchun mos, oflayn ishlaydi (PWA)

## Ishga tushirish
`index.html` faylini brauzerda oching yoki GitHub Pages'ga yuklang.
